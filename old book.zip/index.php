<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Books Sell Home</title>

</head>

<body>
<table width="100%" height="127" border="2" style="background-color:#F00">
  <tr>
    <td><h1><b><marquee>Welcome to Book Stall</marquee></b></h1></td>
  </tr>
</table>
<table width="100%" height="70" border="2" style="background-color:#CCC">
  <tr>
    <form action="" method="post"><td width="35%" ><label style="alignment-adjust:central;"><h1><b>Search book catagory:</b></h1></label>
                    <select style="width:300px;" name="cat"><option>...Select catagory...</option>
                    <option>Story</option>
                    <option>Novel</option>
                    <option>Physics</option>
                    <option>Chem</option>
                    <option>Math</option>
                    <option>ComputerScience</option>
                    </select>
                    <input type="submit" value="search" name="submit">
                     <input type="submit" value="refresh" name="refresh"><a href="index.php">
                    </td>
                    </form>
     <td width="30%"><h1>Want to sell a book?</h1><a href="form.php"><button style="width:300px;">Click here</button></a></td>
    <form action="mystall.php" method="post"><td width="35%"><h1>Go to My Stall</h1> <label>Enter your Emailid:</label>
    <input type="text" name="mail">
   
    <input type="submit" name="submit" type="click here"> </td>
       
      
    
  </tr>
</table>
<table width="100%">
<p></p>
<h1 align="center"><b><i>BOOKS FOR SELL</i></b></h1>
 <tr style="background-color:#CCC">   
         <td>Bookname</td>
         <td>Author</td>
         <td>Category</td>
         <td>Publisher</td>
         <td>Original Price</td>
         <td>Sell price</td>
         <td>Photo</td>
         <td>&nbsp;</td>
 </tr>
      <?php
	      include "connect.php";
		  if (isset($_POST["submit"])){
			  $cat=$_POST["cat"];
			  $result=mysql_query("select * from books where category='$cat'");
			  }
		 else{
			 $result=mysql_query("select * from books");
			 }	
			 while($row=mysql_fetch_array($result)) {
				 echo '<tr>';
				 echo '<td>'.$row["bookname"].'</td>';
				 echo '<td>'.$row["author"].'</td>';
				 echo '<td>'.$row["category"].'</td>';
				 echo '<td>'.$row["publisher"].'</td>';
				 echo '<td>'.$row["orgprice"].'</td>';
				 echo '<td>'.$row["sellprice"].'</td>';
				 echo '<td><img src="'.$row["image"].'" width="70" height="50"></td>';
				echo '<td><a href="contact.php?id='.$row["id"].'"><input type="button" value="contact details"></a></td>';
				 echo '</tr>';
				 } 
	  ?>
      </table>
</body>
</html>