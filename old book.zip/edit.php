<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Form</title>
<script>
 function validateForm()
 {
	 var name = document.forms["form"]["name"]; 
	 var address = document.forms["form"]["address"]; 
	 var phoneno = document.forms["form"]["phoneno"]; 
	 var bookname = document.forms["form"]["bookname"];  
	 var author = document.forms["form"]["author"];
	 var category = document.forms["form"]["category"];  
	 var publisher = document.forms["form"]["publisher"]; 
	 var orgprice = document.forms["form"]["orgprice"]; 
	 var sellprice = document.forms["form"]["sellprice"]; 
	 //validate name
	if (name.value == "")                                  
    { 
        window.alert("Please enter your name."); 
        name.focus(); 
        return false; 
    } 
     //validate address
	if (address.value == "")                               
    { 
        window.alert("Please enter your address."); 
       address.focus(); 
        return false; 
    } 
	//validate phnno
	if (phoneno.value == "")                           
    { 
        window.alert("Please enter your Phone number."); 
        phoneno.focus(); 
        return false; 
    } 
	//validate bookname
	if (bookname.value == "")                                  
    { 
        window.alert("Please enter your book name."); 
        bookname.focus(); 
        return false; 
    } 
    //Validate author
	if (author.value == "")                                  
    { 
        window.alert("Please enter book author name."); 
        author.focus(); 
        return false; 
    }
	//validate category
	if (category.selectedIndex < 1)                  
    { 
        alert("Please select the Category."); 
        category.focus(); 
        return false; 
    } 
   
 	//Validate publisher
	if (publisher.value == "")                  
    { 
        alert("Please enter your publisher."); 
      publisher.focus(); 
        return false; 
    }
	//Validate original price
	if (orgprice.value == "")                  
    { 
        alert("Please enter the book's original price."); 
       orgprice.focus(); 
        return false; 
    }
	if (sellprice.value == "")                  
    { 
        alert("Please enter your selling price."); 
        sellprice.focus(); 
        return false; 
    }
	return true;
	
 
 }
 </script>
</head>

<body style="background-color:#0CF">
<form name ="form" onsubmit="return validateForm()" action="proedit.php" method="post" enctype="multipart/form-data" >
<table width="62%" height="89%" border="0" align="center">
	<?php
					include "connect.php";
					$result=mysql_query("Select * from books where id=".$_GET["id"]);
					$row=mysql_fetch_array($result);
				?>
  <tr>
  <td><h3 align="center">Enter your name:</h3></td>
  <td width="70%"><input type="text" style="width:300px; height:30px;" align="middle" name="name" value="<?php echo $row["name"]; ?>">"></td>
</tr>
<tr>
  <td><h3 align="center">Enter your Address:</h3></td>
  <td width="70%"><textarea style="width:300px;" name="address" value="<?php echo $row["address"]; ?>">"></textarea align="middle" ></td>
</tr>
<tr>
  <td><h3 align="center">Enter your Phone no:</h3></td>
  <td width="70%"><input type="text" style="width:300px; height:30px;" align="middle" name="phoneno" value="<?php echo $row["phoneno"]; ?>">"></td>
</tr>
 <td><h3 align="center">Enter your EmailId:</h3></td>
  <td width="70%"><input type="text" style="width:300px; height:30px;" align="middle" name="email" value="<?php echo $row["email"]; ?>"></td>
</tr>
  <tr>
    <td width="36%"><h3 align="center">Book name:</h3></td>
  	<td width="64%"><input type="text" style="width:300px; height:30px;" align="middle" name="bookname" value="<?php echo $row["bookname"]; ?>"></td>
  </tr>
  <tr>
    <td><h3 align="center">Author name:</h3></td>
  	<td width="64%"><input type="text" style="width:300px; height:30px;" align="middle" name="author" value="<?php echo $row["author"]; ?>"></td>
  </tr>
   <td><h3 align="center">Select Category:</h3></td>
    <td>
                    <select style="width:300px;height:30px;" name="category" value="<?php echo $row["category"]; ?>">
                    <option>...Select Category...</option>
                    <option>Story</option>
                    <option>Novel</option>
                    <option>Physics</option>
                    <option>Chem</option>
                    <option>Math</option>
                    <option>ComputerScience</option>
                    </select>
    </td>
  <tr>
  	<td><h3 align="center">Publisher name:</h3></td>
  	<td width="64%"><input type="text" style="width:300px;height:30px;" align="middle" name="publisher" value="<?php echo $row["publisher"]; ?>"></td>
  </tr>
  <tr>
   
  </tr>
  <tr>
    <td><h3 align="center">Original price:</h3></td>
  	<td width="64%"><input type="text" style="width:300px;height:30px;" align="middle" name="orgprice" value="<?php echo $row["orgprice"]; ?>"></td>
  </tr>
  <tr>
    <td><h3 align="center">Selling price:</h3></td>
  	<td width="64%"><input type="text" style="width:300px;height:30px;" align="middle" name="sellprice" value="<?php echo $row["sellprice"]; ?>"></td>
  </tr>

  <tr>
    <tr>
  	<td height="55"><h3 align="center">Upload a photo:</h3></td>
  	<td width="64%"><input type="file" name="image" id="fileField" style="width:300px;" value="<?php echo $row["image"]; ?>"></td>
  </tr>
  <td height="24"></tr>
</table>
<p align="center">
 <input type="submit" name="submit" id="submit" value="Submit">
 </a>
</form>
</body>
</html>