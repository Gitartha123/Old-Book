<script>
function condel(){
	alert("Are you sure");
	}
</script>
<h1 align="center"><b><i>MY STALL</i></b></h1>
<table width="100%">
 <tr style="background-color:#CCC">   
         <td>Bookname</td>
         <td>Original Price</td>
         <td>Sell Price</td>
         <td>Category</td>
         <td>&nbsp;</td>
         <td>&nbsp;</td>
 </tr>
      <?php
	      include "connect.php";
		  if (isset($_POST["submit"])){
			  $mail=$_POST["mail"];
			  $result=mysql_query("select * from books where email='$mail'");
			  }
		 else{
			 $result=mysql_query("select * from books");
			 }	
			 while($row=mysql_fetch_array($result)) {
				 echo '<tr>';
				 echo '<td>'.$row["bookname"].'</td>';
				 echo '<td>'.$row["orgprice"].'</td>';
				 echo '<td>'.$row["sellprice"].'</td>';
				 echo '<td>'.$row["category"].'</td>';
				echo '<td><a href="edit.php?id='.$row["id"].'"><input type="button" value="edit"></a></td>';
				echo '<td><a href="delete.php?id='.$row["id"].'" onClick="return condel();"><input type="button" value="delete"></a></td>';
				 echo '</tr>';
				 } 
	  ?>
      </table>