<table width="100%">
 <tr style="background-color:#CCC">   
         <td>Seller name</td>
         <td>Address</td>
         <td>Contact no:</td>
         
 </tr>
      <?php
	      include "connect.php";
			  $result=mysql_query("select * from books where id=".$_GET["id"]."");
			 while($row=mysql_fetch_array($result)) {
				 echo '<tr>';
				 echo '<td>'.$row["name"].'</td>';
				 echo '<td>'.$row["address"].'</td>';
				 echo '<td>'.$row["phoneno"].'</td>';
				 echo '</tr>';
				 } 
	  ?>
      </table>