<?php
include "connect.php";
$id=$_GET["id"];
mysql_query("delete from books where id='$id'");
header("location:index.php")
?>