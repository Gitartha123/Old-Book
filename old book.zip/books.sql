/*
Navicat MySQL Data Transfer

Source Server         : con
Source Server Version : 50721
Source Host           : localhost:3306
Source Database       : books

Target Server Type    : MYSQL
Target Server Version : 50721
File Encoding         : 65001

Date: 2019-03-08 13:43:23
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `books`
-- ----------------------------
DROP TABLE IF EXISTS `books`;
CREATE TABLE `books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `bookname` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `orgprice` varchar(255) NOT NULL,
  `sellprice` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of books
-- ----------------------------
INSERT INTO `books` VALUES ('12', 'AMLAN BORDOLOI', 'opposite of hostel 3,AEC, Assam Engineering College Road, jalukbari, guwahati-13', '0910 144 5731', 'amlanbrdl122@gmail.com', 'ABCD', 'HC Verma', 'Physics', 'Assam pub', '100', '50', 'photo/5c8221b6a2ff9.jpg');
