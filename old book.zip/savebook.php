<?php
 include "connect.php";
 if(isset($_POST["submit"]))
 {
	 $name=$_POST["name"];
	 $address=$_POST["address"];
	 $phoneno=$_POST["phoneno"];
	 $email=$_POST["email"];
	 $bookname=$_POST["bookname"];
	 $author=$_POST["author"];
	 $category=$_POST["category"];
	 $publisher=$_POST["publisher"];
	 $orgprice=$_POST["orgprice"];
	 $sellprice=$_POST["sellprice"];
	$target_dir = "photo/";
	$file = $target_dir . basename($_FILES["image"]["name"]);
	
	$fileData = pathinfo(basename($_FILES["image"]["name"]));
	
			
	$fileName = uniqid() . '.' . $fileData['extension'];
	$target_path = "photo/" . $fileName;
		
	while(file_exists($target_path))
	{
		$fileName = uniqid() . '.' . $fileData['extension'];
		$target_path = "photo/" . $fileName;
	}
	move_uploaded_file($_FILES["image"]["tmp_name"], $target_path);
	
	$image="photo/" . $fileName;
	 $sql="insert into books value(null,'$name','$address','$phoneno','$email','$bookname','$author','$category','$publisher','$orgprice','$sellprice','$image')";
	 $result=mysql_query($sql,$link);
	 }
	 if($result){
		  echo '<script>alert("Submitted");</script>';
		  header("location:index.php?ok=1");
		 }
	 else{
		 
		  mysql_error();
		 }	 

?>